#' car_mul
#' @param  z,	 input matrix,  homogeneous effects variables, of dimension nobs x nhomovars, each row is an observation vector.
#' @param  x,    input matrix ,  heterogenous  effects variables, of dimension nobs x nhetervars, each row is an observation vector.
#' @param  y,   response variable, a  quantitative vector
#' @param  k,    the number of clusters
#' @param  lambda,  a value of penalty parameter
#' @param  weights,  weight matrix with dim(x) x dim(x), two choices  are recommended, (x^{T}x)^(1/2) and the identity matrix.
#' @return \item{common_coef}{the homogenous effects, intercept included}
#' @return \item{center}{a matrix of cluster centres}
#' @return \item{cluster}{a vector of integers (from 1:k) indicating the cluster to which each point is allocated}

car_mul<-function(z,x,y,k,lambda,weights)
{

  X0<-x
  Y0<-y
  K0<-k
  n0<-length(Y0)
  lambda0<-lambda
  W<-weights
  Z0<-cbind(as.vector(rep(1,n0)),z)
  m0<-dim(Z0)[2]-1
  p0<-dim(X0)[2]
  Xnew<-(diag(nrow(X0)) %x% t(rep(1,ncol(X0)))) * (t(rep(1,nrow(X0))) %x% X0)#####n0 x (n0*p0)covariate######
  #########the mixture initial value#########
  fit0<-lm(Y0~Z0[,-c(1)]+X0[,1:p0])
  #alpha1<-fit0$coef[1:(m0+1)]
  resi<-Y0-Z0%*%fit0$coef[1:(m0+1)]
  fit<-regmixEM(c(resi), X0, addintercept =FALSE, verb = FALSE, epsilon = 1e-04,k=K0)
  index<-apply(fit$posterior, 1, function(x){which.max(x)})
  beta0<-fit$beta[,index]
  gamma0<-t(as.matrix(kmeans(t(beta0),K0,nstart=25)$center))
  gamma0<-gamma0[,c(order(gamma0[1,]))]
  e=1
  q=1
  while(e>10^(-3)&q<=500)
  {
    beta0_v<-as.vector(beta0)
    alpha0<-solve(t(Z0)%*%Z0)%*%t(Z0)%*%(Y0-Xnew%*%beta0_v)        #####(m0+1) x 1 matrix########
    meangam<-rep(apply(gamma0,1,mean),n0)
    subdiff<-matrix(0,n0*p0,p0)
    weight1<-array(0,dim=c(p0,p0,p0))
    weight2<-array(0,dim=c(n0*p0,p0,p0))
    for(j in 1:p0)
    {
      W0<-t(kronecker(diag(n0),W[j,]))
      gamorder<-sort(W[j,]%*%gamma0)
      tidbeta<-W0%*%beta0_v
      diff<-matrix(0,n0,K0-1)
      for(k in 2:K0)
      {
        diff[,k-1]<-(tidbeta-rep(gamorder[k-1],n0))*(tidbeta>rep(mean(gamorder[(k-1):k]),n0))+(tidbeta-rep(gamorder[k],n0))*(tidbeta<rep(mean(gamorder[(k-1):k]),n0))
      }

      subdiff[,j]<-t(W0)%*%(apply(diff,1,sum))
      weight1[,,j]<-W[j,]%*%t(W[j,])
      weight2[,,j]<-t(W0)%*%matrix(1,n0,1)%*%W[j,]

    }

    sub<-apply(subdiff,1,sum)
    wei<-apply(weight1,1:2,sum)
    wei1<-kronecker(diag(n0),wei)
    wei2<-apply(weight2,1:2,sum)
    V<-t(Xnew)%*%Xnew+2*K0*lambda0*wei1
    sumW<-NULL
    for (l in 1:n0)
    {
      sumW[[l]]<-solve(V[((l-1)*p0+1):(l*p0),((l-1)*p0+1):(l*p0)])
    }

    beta1_v<-bdiag(sumW)%*%(2*lambda0*sub+2*lambda0*wei2%*%apply(gamma0,1,sum)+t(Xnew)%*%(Y0-Z0%*%alpha0))

    #######update gamma####
    beta1<-matrix(beta1_v,p0,n0)
    gamma1<-t(as.matrix(kmeans(t(beta1),K0,nstart=25)$centers))
    gamma1<-gamma1[,c(order(gamma1[1,]))]                 #####p0 x K0 matrix ###########
    e<-max(abs(beta1-beta0))
    #####print(e)
    gamma0<-gamma1
    beta0<-beta1
    q<-q+1
  }

  cat("number of car_mul iterations=", q, "\n")
  a1<-kmeans(t(beta1),K0,nstart=25)$cluster                   #####n0 dimensional vector #######
  re<-list(alpha0,gamma0,a1)
  names(re)<-c("commom_coef","center","cluster")
  return(re)
}






#' car
#' @param  z,	 input matrix,  homogeneous effects variables, of dimension nobs x nhomovars, each row is an observation vector.
#' @param  x,    input matrix ,  heterogenous  effects variables, of dimension nobs x 1, each row is an observation vector.
#' @param  y,    response variable, a  quantitative vector
#' @param  k,    the number of clusters
#' @param  lambda,  a value of penalty parameter
#' @return \item{common_coef}{the homogenous effects, intercept included}
#' @return \item{center}{a vector of cluster centres}
#' @return \item{cluster}{a vector of integers (from 1:k) indicating the cluster to which each point is allocated}

car<-function(z,x,y,k,lambda)
{
  X0<-diag(x[,1])
  Y0<-y
  n0<-length(Y0)
  K0<-k
  lambda0<-lambda
  Z0<-cbind(as.vector(rep(1,n0)),z)#######the ridge initial value######
  Q<-Z0%*%solve(t(Z0)%*%Z0)%*%t(Z0)
  I<-diag(n0)
  P<-I-Q
  beta0<-solve(t(X0)%*%P%*%X0+0.002*I)%*%t(X0)%*%P%*%Y0
  gamma0<-Ckmeans.1d.dp(beta0,k=K0)$centers

  e=1
  q=1
  while(e>10^(-4)&q<=500)
  {
    alpha0<-solve(t(Z0)%*%Z0)%*%t(Z0)%*%(Y0-X0%*%beta0)      #####(m0+1) x 1 matrix########
    diff<-matrix(0,n0,K0-1)
    for(j in 2:K0)
    {
      diff[,j-1]<-2*(beta0-gamma0[j-1])*(beta0>mean(gamma0[(j-1):j]))+2*(beta0-gamma0[j])*(beta0<mean(gamma0[(j-1):j]))
    }
    sumdiff<-apply(diff,1,sum)
    beta1<-solve(t(X0)%*%X0+n0*2*K0*lambda0*I)%*%(n0*lambda0*sumdiff+n0*2*lambda0*sum(gamma0)+t(X0)%*%(Y0-Z0%*%alpha0))
    gamma1<-Ckmeans.1d.dp(beta1,k=K0)$centers                   #####K0 dimensional vector ######
    e<-max(abs(beta1-beta0))
    ####print(e)
    gamma0<-gamma1
    beta0<-beta1
    q=q+1
  }
  cat("number of car iterations=", q, "\n")
  a1<-Ckmeans.1d.dp(beta0,k=K0)$cluster                       #####n0 dimensional vector #######
  re<-list(alpha0,gamma0,a1)

  names(re)<-c("commom_coef","center","cluster")
  return(re)
}






