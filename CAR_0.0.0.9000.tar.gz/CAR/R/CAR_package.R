#' @import Matrix
#' @import MASS
#' @import igraph
#' @import Ckmeans.1d.dp
#' @import e1071
#' @import mixtools
#' @import stats
#'
#' @export car
#' @export car_mul
NULL
